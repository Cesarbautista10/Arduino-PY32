#ifndef _PY32YYXX_LL_CORDIC_H_
#define _PY32YYXX_LL_CORDIC_H_
/* LL raised several warnings, ignore them */
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wunused-parameter"
#pragma GCC diagnostic ignored "-Wstrict-aliasing"
#ifdef __cplusplus
  #pragma GCC diagnostic ignored "-Wregister"
#endif

#if 0 //#ifdefx xx //TODO
#endif
#pragma GCC diagnostic pop
#endif /* _PY32YYXX_LL_CORDIC_H_ */
